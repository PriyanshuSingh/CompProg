/**
 * 
 */
package ap2014.adt;

/**
 * @author manish
 *
 */
public class Result {

}
