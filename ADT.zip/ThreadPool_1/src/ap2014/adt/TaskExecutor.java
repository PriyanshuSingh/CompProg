/**
 * 
 */
package ap2014.adt;

/**
 * @author manish
 *
 */
public class TaskExecutor implements Runnable {
	
	private String name;
	private Thread myThread;
	private Task task;

	/**
	 * @param string
	 */
	public TaskExecutor(String name) {
		this.name = name;
		myThread = new Thread(this, name + "#thread" );
		
	}
	
	/**
	 * 
	 */
	public void wakeUp() {
		// wake up my thread
	}

	/**
	 * @param task
	 */
	public void setTask(Task task) {
		// get task
		
	}

	/**
	 * 
	 */
	public void start() {
		// start my thread
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		// keep processing till system is alive
	}

	/**
	 * @return
	 */
	private boolean isAlive() {
		// TODO Auto-generated method stub
		return false;
	}
}
