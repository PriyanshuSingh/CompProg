/**
 * 
 */
package ap2014.adt;

import java.util.List;

/**
 * @author manish
 * 
 */
public class Distributor implements Runnable {
	private TaskQueue taskQueue;
	private List freePool;
	private List busyPool;
	private List underProcessTasks;
	private List processedTask;
	private Thread myThread;
	

	/**
	 * 
	 */
	public Distributor(TaskQueue taskQueue, List freePool,
			List busyPool) {
		this.taskQueue = taskQueue;
		this.freePool = freePool;
		this.busyPool = busyPool;

	}

	public void assignTask() {
		//get task from q 
		// assign it to an executor
		// change task status
	}

	/**
	 * @return
	 */
	private boolean isAlive() {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		// TODO Auto-generated method stub
	}
	/**
	 * 
	 */
	public void start() {
		// start thre thread
	}
}
