/**
 * 
 */
package ap2014.adt;

/**
 * @author manish
 *
 */
public class Task {
	
	public void notifyUser(){
		// TODO Auto-generated method stub
	}

	/**
	 * @return 
	 * 
	 */
	public void execute() {
		
	}
}
