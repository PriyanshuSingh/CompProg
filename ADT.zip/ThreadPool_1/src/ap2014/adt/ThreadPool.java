/**
 * 
 */
package ap2014.adt;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

/**
 * @author manish
 *
 */
public class ThreadPool {
	TaskExecutor[] executors = null;
	List freePool = null;
	List busyPool = null;
	private TaskQueue taskQueue;
	/**
	 * 
	 */
	public ThreadPool(int poolSize) {
		// Initialise pool
	}
	
	public void createThreads(){
		// create executors
	}
	
	public void startdistributor(){
		// start distributor
	}
}
