/**
 * 
 */

package ap2014.adt;

import java.util.ArrayList;
import java.util.List;

/**
 * @author manish
 *
 */
public class TaskQueue {
	
	private List taskList;
	
	/**
	 * 
	 */
	public TaskQueue() {
		taskList = new ArrayList();
	}

	public void submitTask(Task task){
		taskList.add(task);
	}

	/**
	 * @return
	 */
	public Task getTask() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 */
	public boolean hasTask() {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @return
	 */
	public Task removeTask() {
		return null;
	}
	
	
}
