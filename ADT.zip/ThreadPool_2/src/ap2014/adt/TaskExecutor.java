/**
 * 
 */
package ap2014.adt;

/**
 * @author manish
 *
 */
public class TaskExecutor implements Runnable {
	
	private String name;
	private Thread myThread;
	private Task task;

	/**
	 * @param string
	 */
	public TaskExecutor(String name) {
		this.name = name;
		myThread = new Thread(this, name + "#thread" );
		
	}
	
	/**
	 * 
	 */
	public void wakeUp() {
		myThread.interrupt();
	}

	/**
	 * @param task
	 */
	public void setTask(Task task) {
		this.task = task;
		
	}

	/**
	 * 
	 */
	public void start() {
		myThread.start();
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		while(isAlive()){
			// till this executor is alive keep checking for task	
			if(task != null) {
				task.execute();
				task.notifyUser();
			} else {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					System.out.println("I am : " + ", My sleep was interrupted ");
				}
			}
		}
	}

	/**
	 * @return
	 */
	private boolean isAlive() {
		// TODO Auto-generated method stub
		return false;
	}
}
