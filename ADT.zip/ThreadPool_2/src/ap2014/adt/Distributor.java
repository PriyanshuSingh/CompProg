/**
 * 
 */
package ap2014.adt;

import java.util.List;

/**
 * @author manish
 * 
 */
public class Distributor implements Runnable {
	private TaskQueue taskQueue;
	private List freePool;
	private List busyPool;
	private List underProcessTasks;
	private List processedTask;
	private Thread myThread;
	

	/**
	 * 
	 */
	public Distributor(TaskQueue taskQueue, List freePool,
			List busyPool) {
		this.taskQueue = taskQueue;
		this.freePool = freePool;
		this.busyPool = busyPool;

	}

	public void assignTask() {
		Task task = taskQueue.removeTask();
		underProcessTasks.add(task);
		if (freePool.isEmpty()) {
			// TODO wait for free thread
		} else {

			TaskExecutor executor = (TaskExecutor) freePool.get(0);
			executor.wakeUp();
			freePool.remove(executor);
			busyPool.add(executor);
			executor.setTask(task);
			underProcessTasks.remove(task);
			processedTask.add(task);
		}
	}

	/**
	 * @return
	 */
	private boolean isAlive() {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		while (isAlive()) {
			while(taskQueue.hasTask()){
				assignTask();
			}
		}
	}

	/**
	 * 
	 */
	public void start() {
		myThread = new Thread(this, "Distributor#Thread");
		myThread.start();
	}
}
