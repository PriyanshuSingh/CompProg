/**
 * 
 */
package ap2014.adt;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

/**
 * @author manish
 *
 */
public class ThreadPool {
	TaskExecutor[] executors = null;
	List freePool = null;
	List busyPool = null;
	private TaskQueue taskQueue;
	/**
	 * 
	 */
	public ThreadPool(int poolSize) {
		executors = new TaskExecutor[poolSize];
		freePool = new ArrayList(poolSize);
		busyPool = new ArrayList(poolSize);
		taskQueue = new TaskQueue();
	}
	
	public void createThreads(){
		for (int i = 0; i < executors.length; i++) {
			executors[i] = new TaskExecutor("Executor " + i);
			freePool.add(executors[i]);
			executors[i].start();
		}
	}
	
	public void startdistributor(){
		Distributor  distributor = new Distributor(taskQueue, freePool, busyPool);
		distributor.start();
	}
}
