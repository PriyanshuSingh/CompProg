package ap2014.assignment3.mainclass;

import ap2014.assignment3.mainProj.Racer;
import ap2014.assignment3.mainProj.Session;
import ap2014.assignment3.mainProj.Track;
import ap2014.assignment3.mainProj.racerInterface.Cyclist;
import ap2014.assignment3.mainProj.racerInterface.Runner;
import ap2014.assignment3.mainProj.racerInterface.Swimmer;

public class MainClass {

	final static int NoOfRacer=10;
	
	public static void main(String[] args){
		
		Session session = new Session();
		Racer[] racerArr = session.giveRacer(NoOfRacer);
		Track track = session.giveTrack();
		Thread[] racerThread = new Thread[NoOfRacer];
		
		System.out.println("----Preparing for Race----\n");
		session.prepareForRace(racerArr, track, racerThread);
		
		System.out.println();
		System.out.println();
		session.startRace(racerThread);
		
		for(int i=0; i<racerThread.length;i++){
			try {
				racerThread[i].join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		for(int i=0;i<racerArr.length;i++){
			racerArr[i].setCyclingTime(track.cyclingSection.getCyclingTime((Cyclist)racerArr[i]));
			racerArr[i].setRunningTime(track.runningSection.getRunningTime((Runner)racerArr[i]));
			racerArr[i].setSwimmingTime(track.swimmingSection.getSwimmerTime((Swimmer)racerArr[i]));
		}
		
		
	}
	
	
}
