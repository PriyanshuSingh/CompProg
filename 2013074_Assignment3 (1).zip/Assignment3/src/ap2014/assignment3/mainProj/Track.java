package ap2014.assignment3.mainProj;

import java.util.Random;

import ap2014.assignment3.mainProj.trackSection.CyclingSection;
import ap2014.assignment3.mainProj.trackSection.RunningSection;
import ap2014.assignment3.mainProj.trackSection.SwimmingSection;

public class Track {

	public CyclingSection cyclingSection;
	public RunningSection runningSection;
	public SwimmingSection swimmingSection;
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String str = String.format("SectionType\t\tSectionLength\n") +
				String.format(" Running \t\t %d",this.runningSection.lengthOfTrack) +
				String.format(" Cycling \t\t %d", this.cyclingSection.lengthOfTrack) +
				String.format(" Swimming\t\t %d", this.swimmingSection.lengthOfTrack);
		return str;
	}
	public Track() {
		Random rn = new Random();
		this.cyclingSection = new CyclingSection();
		this.cyclingSection.lengthOfTrack = rn.nextInt(7000)+1000;
		this.runningSection = new RunningSection();
		this.runningSection.lengthOfTrack = rn.nextInt(7000)+1000;
		this.swimmingSection = new SwimmingSection();
		this.swimmingSection.lengthOfTrack = rn.nextInt(7000)+1000;
	}
	
	
}
