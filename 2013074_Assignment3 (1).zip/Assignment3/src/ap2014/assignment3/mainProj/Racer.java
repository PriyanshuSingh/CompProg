package ap2014.assignment3.mainProj;

import java.util.Random;

import ap2014.assignment3.mainProj.racerInterface.Cyclist;
import ap2014.assignment3.mainProj.racerInterface.Runner;
import ap2014.assignment3.mainProj.racerInterface.Swimmer;
import ap2014.assignment3.mainProj.trackSection.CyclingSection;
import ap2014.assignment3.mainProj.trackSection.RunningSection;
import ap2014.assignment3.mainProj.trackSection.SwimmingSection;

public class Racer implements Runner,Swimmer,Cyclist,Runnable,Comparable<Racer>{

	public String name;
	public int contestantID;
	private double leapCoverage;
	private double leapFrequency;
	private double pedalFrequency;
	private double strokeFrequency;
	private double strokeCoverage;
	private int noOfPedals;
	private int noOfLeaps;
	private int noOfStrokes;
	private double totalTime;
	private double runningTime;
	private double swimmingTime;
	private double cyclingTime;
	Track track;

	@Override
	public double getLeapCoverage() {
		// TODO Auto-generated method stub
		return leapCoverage;
	}
	@Override
	public double getLeapFrequency() {
		// TODO Auto-generated method stub
		return leapFrequency;
	}
	@Override
	public double getPedalFrequency() {
		// TODO Auto-generated method stub
		return pedalFrequency;
	}
	@Override
	public double getStrokeFrequency() {
		// TODO Auto-generated method stub
		return strokeFrequency;
	}
	@Override
	public double getStrokeCoverage() {
		// TODO Auto-generated method stub
		return strokeCoverage;
	}
	
	public void setRacerOnTrack(Track track){
		this.track = track;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		this.coverCyclingSection(this.track.cyclingSection);
		this.coverRunningSection(this.track.runningSection);
		this.coverSwimmingSection(this.track.swimmingSection);
	}
	@Override
	public int getNoofPedal() {
		// TODO Auto-generated method stub
		return this.noOfPedals;
	}
	@Override
	public void coverCyclingSection(CyclingSection cyclingSection) {
		// TODO Auto-generated method stub
		double lengthCovered = 0.0;
		this.noOfPedals = 0;
		while(cyclingSection.lengthOfTrack - lengthCovered > 0){
			lengthCovered += Cyclist.cycle.getPedalCoverage();
			this.noOfPedals++;
		}
		this.noOfPedals++;
	}
	@Override
	public int getNoofStrokes() {
		// TODO Auto-generated method stub
		return this.noOfStrokes;
	}
	@Override
	public void coverSwimmingSection(SwimmingSection swimmingSection) {
		// TODO Auto-generated method stub
		double lengthCovered = 0.0;
		this.noOfStrokes = 0;
		while(swimmingSection.lengthOfTrack - lengthCovered > 0){
			lengthCovered += this.getStrokeCoverage();
			this.noOfStrokes++;
		}
		this.noOfLeaps++;
	}
	@Override
	public int getNoofLeaps() {
		// TODO Auto-generated method stub
		return this.noOfLeaps;
	}
	@Override
	public void coverRunningSection(RunningSection runningSection) {
		// TODO Auto-generated method stub
		double lengthCovered = 0.0;
		this.noOfLeaps = 0;
		while(runningSection.lengthOfTrack - lengthCovered > 0){
			lengthCovered += this.getLeapCoverage();
			this.noOfLeaps++;
		}
		this.noOfLeaps++;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String str = String.format("Racer Name: %s\n",this.name) +
				String.format("Contestant ID: %d\n ", this.contestantID) +
				String.format("Leap Coverage: %d\n",this.leapCoverage) +
				String.format("Leap Frequency: %d\n", this.leapFrequency) +
				String.format("Stroke Coverage: %d\n", this.strokeCoverage) +
				String.format("Stroke Frequency: %d\n", this.strokeFrequency) +
				String.format("Pedal Coverage: %d\n", Cyclist.cycle.getPedalCoverage()) +
				String.format("Pedal Frequency: %d\n", this.pedalFrequency);
		return str;
	}
	public Racer(String name, int contestantID) {
		super();
		this.name = name;
		this.contestantID = contestantID;
		Random rn = new Random();
		this.leapCoverage = rn.nextDouble()*10 + 5;
		this.leapFrequency = rn.nextDouble()*10 + 5;
		this.pedalFrequency = rn.nextDouble()*10 + 5;
		this.strokeFrequency = rn.nextDouble()*10 + 5;
		this.strokeCoverage = rn.nextDouble()*10 + 5;
	}
	@Override
	public int compareTo(Racer racer2) {
		// TODO Auto-generated method stub
		if(this.totalTime < racer2.totalTime){
			return 1;
		}
		else{
			return -1;
		}
	}
	/**
	 * @return the totalTime
	 */
	public double getTotalTime() {
		return totalTime;
	}
	/**
	 * @param totalTime the totalTime to set
	 */
	public void setTotalTime(double totalTime) {
		this.totalTime = totalTime;
	}
	/**
	 * @return the swimmingTime
	 */
	public double getSwimmingTime() {
		return swimmingTime;
	}
	/**
	 * @param swimmingTime the swimmingTime to set
	 */
	public void setSwimmingTime(double swimmingTime) {
		this.swimmingTime = swimmingTime;
	}
	/**
	 * @param strokeFrequency the strokeFrequency to set
	 */
	public void setStrokeFrequency(double strokeFrequency) {
		this.strokeFrequency = strokeFrequency;
	}
	/**
	 * @param strokeCoverage the strokeCoverage to set
	 */
	public void setStrokeCoverage(double strokeCoverage) {
		this.strokeCoverage = strokeCoverage;
	}
	/**
	 * @return the runningTime
	 */
	public double getRunningTime() {
		return runningTime;
	}
	/**
	 * @param runningTime the runningTime to set
	 */
	public void setRunningTime(double runningTime) {
		this.runningTime = runningTime;
	}
	/**
	 * @return the cyclingTime
	 */
	public double getCyclingTime() {
		return cyclingTime;
	}
	/**
	 * @param cyclingTime the cyclingTime to set
	 */
	public void setCyclingTime(double cyclingTime) {
		this.cyclingTime = cyclingTime;
	}

}
