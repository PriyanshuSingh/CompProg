package ap2014.assignment3.mainProj;

import java.util.Random;

public class Session {
	
	public Racer[] giveRacer(int n){
		Racer[] racerArr = new Racer[n];
		Random rn = new Random();
		for(int i =1; i < racerArr.length;i++){
			racerArr[i] = new Racer(String.format("RACER%d", i), rn.nextInt());
			System.out.print("---------Racer created--------\n"+racerArr[i]);
		}
		
		return racerArr;
	}
	
	public Track giveTrack(){
		Track track = new Track();
		System.out.println();
		System.out.println();
		System.out.print("-------Track created--------\n"+track);
		return track;
		
	}
	
	public void prepareForRace(Racer[] racerArr,Track track,Thread[] RacerThread){
		for(int i=0;i<racerArr.length;i++){
			racerArr[i].setRacerOnTrack(track);
			RacerThread[i] = new Thread(racerArr[i]);
		}
	}
	
	public void startRace(Thread[] racerThread){
		System.out.println("---- Starting Race ----");
		for(int i=0;i<racerThread.length;i++){
			racerThread[i].start();
		}
	}
}

