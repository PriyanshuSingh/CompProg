package ap2014.assignment3.mainProj.racerInterface;

import ap2014.assignment3.mainProj.trackSection.CyclingSection;

public interface Cyclist {

	public Cycle cycle = new Cycle();
	public double getPedalFrequency();
	public int getNoofPedal();
	public void coverCyclingSection(CyclingSection cycingSection);
}
