package ap2014.assignment3.mainProj.racerInterface;

public class Cycle {

	final int pedalCoverage = 10;

	/**
	 * @return the pedalCoverage
	 */
	public int getPedalCoverage() {
		return pedalCoverage;
	}
}
