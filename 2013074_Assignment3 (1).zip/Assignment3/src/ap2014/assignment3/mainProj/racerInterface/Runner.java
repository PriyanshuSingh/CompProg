package ap2014.assignment3.mainProj.racerInterface;

import ap2014.assignment3.mainProj.trackSection.RunningSection;

public interface Runner {

	public double getLeapCoverage();
	public double getLeapFrequency();
	public int getNoofLeaps();
	public void coverRunningSection(RunningSection runningSection);
}
