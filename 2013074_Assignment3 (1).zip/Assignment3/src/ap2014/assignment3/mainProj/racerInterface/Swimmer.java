package ap2014.assignment3.mainProj.racerInterface;

import ap2014.assignment3.mainProj.trackSection.SwimmingSection;

public interface Swimmer {

	public double getStrokeFrequency();
	public double getStrokeCoverage();
	public int getNoofStrokes();
	public void coverSwimmingSection(SwimmingSection swimmingSection);
}
