package ap2014.assignment3.mainProj.trackSection;

import ap2014.assignment3.mainProj.racerInterface.Cyclist;

public class CyclingSection extends RaceSection{

	public double getCyclingTime(Cyclist cyclist){
		return (double)cyclist.getNoofPedal()/cyclist.getPedalFrequency();
	}
}
