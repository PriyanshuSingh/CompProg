package ap2014.assignment3.mainProj.trackSection;

import ap2014.assignment3.mainProj.racerInterface.Runner;

public class RunningSection extends RaceSection{

	public double getRunningTime(Runner runner){
		return (double)runner.getNoofLeaps()/runner.getLeapFrequency();
	}
}
