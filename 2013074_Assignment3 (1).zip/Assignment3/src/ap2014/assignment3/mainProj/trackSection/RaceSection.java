package ap2014.assignment3.mainProj.trackSection;

public class RaceSection{

	public int lengthOfTrack;
}
