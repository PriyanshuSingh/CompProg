package ap2014.assignment3.mainProj.trackSection;

import ap2014.assignment3.mainProj.racerInterface.Swimmer;

public class SwimmingSection extends RaceSection{

	public double getSwimmerTime(Swimmer swimmer){
		return (double)swimmer.getNoofStrokes()/swimmer.getStrokeFrequency();
	}
}
