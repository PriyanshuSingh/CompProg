#include <stdio.h>
#include <stdlib.h>


int main(){
    system("gcc -w -o run 2013074_A3.c && gnome-terminal -e ./run");
    return 0;
}
