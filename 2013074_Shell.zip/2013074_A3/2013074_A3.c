#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>


void sighandler(int);
pid_t pid;
pid_t pidComplete;
char *arg[100]={NULL};
int argp = 0;
char buff[100];

void shellPrompt(){
    printf("[Shell]%s $",getcwd(buff,1024));
}

void flushArg(){
    while(argp != 0){
	arg[argp] = NULL;
	argp--;
    }
}

int  getUserInput(){
    flushArg();
    char *bufferPointer;
    gets(buff);
    if(buff[0] == '\0'){
	return 1;
    }
    else{
	bufferPointer = strtok(buff," ");
	while(bufferPointer != NULL){
	    arg[argp] = bufferPointer;
	    bufferPointer = strtok(NULL," ");
	    argp++;
	}
    }

}


int main(){
    signal(SIGINT,sighandler);
    while(1){
	shellPrompt();
	getUserInput();
	if(arg[0] != NULL){
	    if(strcmp("cd",arg[0]) == 0){
		if(arg[1] == NULL){
		    chdir(getenv("HOME"));	
		}
		else{
		    if(chdir(arg[1]) == -1){
			    printf(" %s: no such directory\n", arg[1]);
		    }
		}
	    }
	    else if(strcmp("exit",arg[0]) == 0){
		exit(EXIT_SUCCESS);
	    }
	    else if((pid = fork())  == 0){
		if(execvp(arg[0],arg) == -1){
		    printf("%s: command not found\n",arg[0]);
		}
		exit(0);
	    }
	    else if(pid > 0){
		/* printf("parent first\n"); */
		pidComplete = wait(0);
	    }
	    else{
		printf("ERROR");
	    }
	}
    }
    return 0;
}

void sighandler(int sig){
    if(pid > 0 && pid != pidComplete){
	if(!kill(pid, SIGKILL)){
	    printf("\n [shell] : killing process (pid = %d)\n",pid);
	    /* shellPrompt(); */
	}
	/* pid = -1; */
    }
}
